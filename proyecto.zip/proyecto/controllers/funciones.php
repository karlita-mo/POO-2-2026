

<?php
//Funcion de Acceso al Login
// AL = AccesoLogin
function AL(string $user, string $pass, string $tabla, string $campo)
{
    // Intanciar el objeto de la Clase Proceso
    $procesos = new procesos();
    // Obtener datos del usuario
    $data = $procesos->GDU($user, $tabla, $campo);
    // Crear Condiciones de Acceso
    if ($data && is_array($data)) {
        if ($data['estado'] == 1) {
            if (password_verify($pass, $data['pass'])) {
                session_start();
                $_SESSION['login_ok'] = true;
                $_SESSION['idusuario'] = $data['idusuario'];
                $_SESSION['usuario'] = $user;
                $_SESSION['idrol'] = $data['idrol'];

                echo '
                    <script>
                            alert("Bienvenido/a");
                            setTimeout(
                                function(){
                                window.location.href = "../index.php";
                                },500
                        );
                    </script>
                    ';
            } else {
                echo '
                        <script>
                            alert("Error Contraseña Incorrecta");
                            setTimeout(
                                function(){
                                window.location.href = "../index.php";
                                },500
                        );
                    </script>
                ';
            }
        } else {
            echo '
            <script>
                    alert("Error Usuario sin permisos de acceso");
                    setTimeout(
                        function(){
                        window.location.href = "../index.php";
                        },500
                    );
                </script>
                ';
        }
    } else {
        // Error Usuario o Email no existen
        echo '
     <script>
            alert("Error Usuario o Email no existen");
            setTimeout(
                function(){
                window.location.href = "../index.php";
                },500
        );
     </script>
     ';
    }
}
