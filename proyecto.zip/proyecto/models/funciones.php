<?php
//datos de usuario para iniciar session
class Procesos{
    // GDU = Get Data User
    public function GDU($user,$tabla,$campo){
        $row = [];
        $modelo = new Conexion();
        $conexion = $modelo->getConexion();
        $arg = ":".$campo; // :usuario O :email
        $query = "SELECT * FROM $tabla WHERE $campo = $arg OR email = $arg";
        $stmt = $conexion->prepare($query);// Statement
        $stmt->bindParam($arg,$user);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $modelo->closeConexion();
        return $row;
    } 
}